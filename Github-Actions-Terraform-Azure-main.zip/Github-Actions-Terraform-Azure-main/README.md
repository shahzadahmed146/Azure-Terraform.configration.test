##### ![#c5f015](https://via.placeholder.com/15/c5f015/000000?text=+) <font size =10> GitHub Actions and Terraform : Implementing Infrastructure on Azure : </font> 
 
 ![#f03c15](https://via.placeholder.com/15/f03c15/000000?text=+) Watch YouTube Video to complete below excerise - Start to Finish
 
Create Azure Storage Account for tf State file.<br>
Create Service Principal.<br>
Create Github Repository.<br>
Create GitHub Action Workflow file.<br>
Create Terraform files.<br>
Push Git Repository.<br>
Track Github Action Workflow<br>



[![](http://img.youtube.com/vi/Wfo3E9YkFSk/0.jpg)](http://www.youtube.com/watch?v=Wfo3E9YkFSk" "Click Here to Watch Video")


  ![#f03c15](https://via.placeholder.com/15/f03c15/000000?text=+) Watch more Videos on - YouTube.com/DevopsGuru

# Terraform-App-Rrgistration-Azure-AD
https://youtu.be/t4mHYKeqW_Q
